using System;

namespace NHibernate.Test.CompositeCollection
{
	/// <summary>
	/// Summary description for CompositeCollection.
	/// </summary>
	public class CompositeCollection
	{
		public CompositeCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}