namespace NHibernate.Test.DynamicEntity
{
	public interface IProxyMarker
	{
		DataProxyHandler DataHandler { get;}
	}
}