﻿namespace NHibernate.Test.Component.Basic
{
	public class OptionalComponent
	{	
		public string Value1 { get; set; }
		public string Value2 { get; set; }
	}
}