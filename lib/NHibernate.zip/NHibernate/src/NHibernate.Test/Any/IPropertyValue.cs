namespace NHibernate.Test.Any
{
	public interface IPropertyValue
	{
		string AsString();
	}
}