using System;

namespace NHibernate.DomainModel
{
	[Serializable]
	public class Multiplicity
	{
		public int count;
		public GlarchProxy glarch;
	}
}